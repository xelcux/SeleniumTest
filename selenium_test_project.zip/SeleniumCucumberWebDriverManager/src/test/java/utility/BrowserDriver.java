package utility;

import org.openqa.selenium.WebDriver;

public class BrowserDriver {


    public static WebDriver driver;

}
